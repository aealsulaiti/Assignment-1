# Discovery Bay Golf and Country Club Restaurant

## Overview

Welcome to the Discovery Bay Golf and Country Club Restaurant! This C++ console application allows customers to place orders from the restaurant's menu, comprising meals and desserts. The program calculates the subtotal, applies a sales tax of 8%, and provides the total amount, which is billed to the customer's member charge.

### Menu

Explore the diverse menu options offered at the Discovery Bay Golf and Country Club Restaurant:

#### Meals

- Discovery Bay Burger (B) - $15.00
- Turkey, Bacon & Avocado (T) - $15.00
- DB Clubhouse (C) - $16.00
- Chicken Quesadilla (Q) - $11.50
- Chicken Fries (F) - $11.00

#### Desserts

- Pie (P) - $5.00
- Ice Cream (I) - $3.00
- Cookies (C) - $3.00
- One Pancake (O) - $4.00

## How to Use

1. **Clone the Repository:**
2. **Compile and Run:**
   - Compile the C++ code using a C++ compiler (e.g., g++).
   - Run the compiled executable.

## Place Your Order:

- Enter the meal choice (B, T, C, Q, F) when prompted.
- Enter the dessert choice (P, I, C, O) when prompted.

## View Results:

- The application will calculate the subtotal, apply sales tax, and display the total amount billed to the member charge.

## Thank You:

- Thank you for dining with us at Discovery Bay Golf and Country Club! Your satisfaction is our priority, and we hope to see you again soon.

## OUTPUT:

![6357d94d-f08a-4373-99ca-f2e753beccec](C:\Users\pc\Downloads\6357d94d-f08a-4373-99ca-f2e753beccec.jpeg)