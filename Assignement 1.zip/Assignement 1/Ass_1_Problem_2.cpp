#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    // Menu items and prices
    const double BURGER_PRICE = 15.00;
    const double PIE_PRICE = 5.00;
    const double PASTA_PRICE = 12.00;
    const double ICE_CREAM_PRICE = 6.00;
    const double TURKEY_BACON_AVOCADO_PRICE = 15.00;
    const double DB_CLUBHOUSE_PRICE = 16.00;
    const double CHICKEN_QUESADILLA_PRICE = 11.50;
    const double CHICKEN_FRIES_PRICE = 11.00;

    const double ICE_CREAM_DESERT_PRICE = 3.00;
    const double COOKIES_DESERT_PRICE = 3.00;
    const double ONE_PANCAKE_DESERT_PRICE = 4.00;

    // Display welcome message and menu
    cout << "****Welcome to Discovery Bay Golf and Country Club Restaurant***" << endl;
    
    // Display Meal Menu
    cout << "| Meal                            | Price |" << endl;
    cout << "***********************" << endl;
    cout << "Discovery Bay Burger (B)         $15.00" << endl;
    cout << "Turkey, Bacon & Avocado (T)      $15.00" << endl;
    cout << "DB Clubhouse (C)                 $16.00" << endl;
    cout << "Chicken Quesadilla (Q)           $11.50" << endl;
    cout << "Chicken Fries (F)                $11.00" << endl;

    // Display Dessert Menu
    cout << "| Dessert                         | Price |" << endl;
    cout << "***********************" << endl;
    cout << "Pie (P)                          $5.00" << endl;
    cout << "Ice Cream (I)                    $3.00" << endl;
    cout << "Cookies (C)                      $3.00" << endl;
    cout << "One Pancake (O)                  $4.00" << endl;

    // Get user input for meal and dessert
    char mealChoice, desertChoice;
    cout << "Enter a Meal that you would like to order: ";
    cin >> mealChoice;
    cout << "Enter a Dessert that you would like to order: ";
    cin >> desertChoice;

    // Calculate subtotal
    double subtotal = 0.0;
    switch (mealChoice) {
        case 'B':
            subtotal += BURGER_PRICE;
            break;
        case 'T':
            subtotal += TURKEY_BACON_AVOCADO_PRICE;
            break;
        case 'C':
            subtotal += DB_CLUBHOUSE_PRICE;
            break;
        case 'Q':
            subtotal += CHICKEN_QUESADILLA_PRICE;
            break;
        case 'F':
            subtotal += CHICKEN_FRIES_PRICE;
            break;
        default:
            cout << "Invalid Meal choice!" << endl;
            return 1; // Exit with an error code
    }

    switch (desertChoice) {
        case 'P':
            subtotal += PIE_PRICE;
            break;
        case 'I':
            subtotal += ICE_CREAM_DESERT_PRICE;
            break;
        case 'C':
            subtotal += COOKIES_DESERT_PRICE;
            break;
        case 'O':
            subtotal += ONE_PANCAKE_DESERT_PRICE;
            break;
        default:
            cout << "Invalid Dessert choice!" << endl;
            return 1; // Exit with an error code
    }

    // Calculate sales tax (assuming 8% sales tax)
    double salesTaxRate = 0.08;
    double salesTax = subtotal * salesTaxRate;

    // Calculate total
    double total = subtotal + salesTax;

    // Display results
    cout << fixed << setprecision(2);
    cout << "Sales Tax: $" << salesTax << endl;
    cout << "Your total is $" << total << " and this will go to member charge!" << endl;
    cout << "Thank you for dining with us at Discovery Bay Golf and Country Club! You made Matt Padilla happy :)" << endl;

    return 0;
}
