# Gas 4 Taxes

## OverviewOverview
Welcome to Gas 4 Taxes, a simple C++ console application for calculating and processing gas purchases. This application provides information about gas prices for different types, allows users to select a gas type and specify the number of gallons they want to purchase, calculates the total cost with sales tax, and accepts various payment methods.
## Intended Audience
Gas 4 Taxes is designed for individuals who want a quick and easy way to calculate the cost of filling up their vehicles with different types of gas. It is suitable for anyone who needs a basic tool for estimating fuel expenses.
## Problem Statement
People often need to know the total cost of filling up their cars with gas, taking into account different gas types and sales tax. Gas 4 Taxes addresses this need by providing a straightforward solution for calculating and displaying the total cost.
## FeaturesFeatures
### Gas Price Information:
Displays current gas prices for Regular, Midgrade, Premium, and Diesel.
### User Interaction:
Prompts the user to choose a gas type (Regular, Midgrade, Premium, Diesel).
Takes input for the number of gallons the user wants to purchase.
### Price Calculation:
Calculates the total price based on the selected gas type and gallons.
### Sales Tax:
Applies a predefined sales tax rate (8%) to the total price.
### Payment Method:
Asks the user to choose a payment method (Debit Card, Credit Card, Gift Card, Cash).
Displays a confirmation message with the total amount paid and the chosen payment method.
## How to Run the App
### Clone the Repository:
### Compile and Run:
Compile the C++ code using a C++ compiler (e.g., g++).
Run the compiled executable.
## Follow On-Screen Instructions:
Choose a gas type (R/r for Regular, M/m for Midgrade, P/p for Premium, D/d for Diesel).
Enter the number of gallons.
Enter the payment method when prompted.
## View Results:
The app will display the total cost and payment confirmation.
## Thank You:
Thank you for using Gas 4 Taxes! Feel free to contribute or provide feedback.

## Output:

![d82df781-c087-458c-9db2-1a07d3a2459c](C:\Users\pc\Downloads\d82df781-c087-458c-9db2-1a07d3a2459c.jpeg)