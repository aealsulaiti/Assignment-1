#include <iostream>
#include <iomanip>
#include <string>

int main() {
    // Gas station information
    std::cout << "--------------------------------------Welcome to Gas 4 Taxes--------------------------------------\n";
    std::cout << "| Gas Type | Price |\n";
    std::cout << "-------------------------------------------------------------------------------------------------------------\n";
    std::cout << "| Regular  | $5.02 |\n";
    std::cout << "-------------------------------------------------------------------------------------------------------------\n";
    std::cout << "| Midgrade | $5.22 |\n";
    std::cout << "-------------------------------------------------------------------------------------------------------------\n";
    std::cout << "| Premium  | $5.42 |\n";
    std::cout << "-------------------------------------------------------------------------------------------------------------\n";
    std::cout << "| Diesel   | $6.03 |\n";
    std::cout << "-------------------------------------------------------------------------------------------------------------\n";

    // User input
    char gasType;
    double gallons;

    std::cout << "Choose a gas type to fill up your car: ";
    std::cin >> gasType;

    std::cout << "How many gallons: ";
    std::cin >> gallons;

    // Gas prices
    double gasPrice;
    switch (gasType) {
        case 'R':
        case 'r':
            gasPrice = 5.02;
            break;
        case 'M':
        case 'm':
            gasPrice = 5.22;
            break;
        case 'P':
        case 'p':
            gasPrice = 5.42;
            break;
        case 'D':
        case 'd':
            gasPrice = 6.03;
            break;
        default:
            std::cout << "Invalid gas type selected.\n";
            return 1; // Exit with an error code
    }

    // Calculate total price
    double totalPrice = gasPrice * gallons;

    // Calculate total value with sales tax
    const double salesTaxRate = 0.08; // Assuming 8% sales tax
    double totalValue = totalPrice * (1 + salesTaxRate);

    // Output the total price
    std::cout << "\nYour total is $" << std::fixed << std::setprecision(2) << totalPrice << ".\n";

    // Payment method
    std::string paymentMethod;
    std::cout << "How would you like to pay for it? (Debit Card, Credit Card, Gift Card, Cash): ";
    std::cin.ignore(); // Ignore newline character left in the buffer
    std::getline(std::cin, paymentMethod);

    // Output the payment information
    std::cout << "\nGreat! You have paid the balance of $" << totalValue << " using your " << paymentMethod << ".\n";
    std::cout << "Thank you for filling up gas at Gas 4 Taxes, a place to get broke!\n";

    return 0;
}
